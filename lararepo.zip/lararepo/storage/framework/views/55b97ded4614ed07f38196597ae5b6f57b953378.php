<!DOCTYPE html>
<html>
   <head>
      <meta name="viewport" content="width=device-width">
      <title>Laravel Repositories and Services</title>
      <meta name="description" content="">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
      <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" crossorigin="anonymous">
   </head>
   <body>
      <div class="container">
         <div class="col-md-5">
            <h4 class="page-header">Laravel Repositories and Services </h4>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="alert alert-danger"><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissable">
               <a href="#" class="close" data-dismiss="alert" aria-label="close">x</a>
               <?php echo e(session('status')); ?>

            </div>
            <?php endif; ?>
            <form class="form-vertical" role="form" method="post" action="<?php echo e(route('create.post')); ?>">
               <?php echo e(csrf_field()); ?>

               <div class="form-group">
                  <input type="text" name="title" class="form-control" placeholder="Title">
               </div>
               <div class="form-group">
                  <textarea class="form-control" rows="5" name="body" class="form-control" placeholder="Content"></textarea>
               </div>
               <div class="form-group">
                  <button type="submit" class="btn btn-info">Submit Post</button>
               </div>
            </form>
            <table class="table table-bordered">
               <thead>
                  <tr>
                     <th>Title</th>
                     <th>Content </th>
                     <th>Edit</th>
                     <th>Delete</th>
                  </tr>
               </thead>
               <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tbody>
                  <tr>
                     <td><?php echo e($post->title); ?></td>
                     <td><?php echo e($post->body); ?></td>
                     <form action="<?php echo e(route('edit.post', $post->id)); ?>" method="GET">
                        <td>
                           <p data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-success btn-xs" ><span class="fa fa-pencil fa-fw"></span></button></p>
                        </td>
                     </form>
                     <form action="<?php echo e(route('destroy.post', $post->id)); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <td>
                           <p data-placement="top" data-toggle="tooltip" title="Delete"><button class="btn btn-danger btn-xs" ><span class="fa fa-fw fa-trash"></span></button></p>
                        </td>
                     </form>
                  </tr>
               </tbody>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
         </div>
      </div>
   </body>
</html>